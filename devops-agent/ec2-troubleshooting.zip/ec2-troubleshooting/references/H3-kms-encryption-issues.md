---
title: "H3 — KMS / Encryption Issues"
description: "Diagnose EBS encryption and KMS key access failures"
status: active
severity: HIGH
triggers:
  - "KMS.*AccessDenied"
  - "VolumeInUse.*encrypted"
  - "Client.InternalError.*encrypted"
  - "KMSKeyNotAccessible"
owner: devops-agent
objective: "Restore KMS key access for encrypted EBS volumes"
context: "Encrypted EBS volumes require KMS key access for every I/O operation. If the KMS key is deleted, disabled, or the instance role loses access, the volume becomes unusable. Default EBS encryption uses the aws/ebs key. Custom CMKs require explicit grants."
---

## Phase 1 — Triage

MUST:
- Check volume encryption: `aws ec2 describe-volumes --volume-ids <vol-id>` → Encrypted, KmsKeyId
- Check KMS key state: `aws kms describe-key --key-id <key-id>` — must be Enabled
- Check if instance role has kms:Decrypt and kms:CreateGrant on the key
- Check KMS key policy allows the instance role

SHOULD:
- Check if the key is in a different account (cross-account KMS)
- Verify KMS key grants: `aws kms list-grants --key-id <key-id>`

## Common Issues

- symptoms: "Instance fails to start with encrypted root volume"
  diagnosis: "KMS key disabled, deleted, or instance role lacks permissions."
  resolution: "Re-enable key, or grant kms:Decrypt and kms:CreateGrant to the instance role."

- symptoms: "Client.InternalError on encrypted volume operations"
  diagnosis: "KMS key not accessible. Often a key policy or grant issue."
  resolution: "Check key policy. Add grant for the instance role. Verify key is enabled."

## Output Format

```yaml
root_cause: "<key_disabled|key_deleted|missing_permission|cross_account|key_policy>"
evidence:
  - type: kms_key_state
    content: "<describe-key output>"
severity: HIGH
mitigation:
  immediate: "Re-enable key or fix permissions"
  long_term: "Use key policies with least privilege, monitor key state"
```
