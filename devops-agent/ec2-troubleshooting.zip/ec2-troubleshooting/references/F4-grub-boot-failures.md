---
title: "F4 — GRUB / Boot Loader Failures"
description: "Diagnose boot loader failures preventing instance startup"
status: active
severity: CRITICAL
triggers:
  - "GRUB.*error"
  - "error.*loading.*kernel"
  - "Booting from Hard Disk"
  - "grub rescue"
owner: devops-agent
objective: "Repair the boot loader and restore the instance to a bootable state"
context: "GRUB failures prevent the kernel from loading. Common causes: corrupt GRUB config, missing kernel files, wrong root device in GRUB, or GRUB installation corruption. Screenshot shows GRUB menu or rescue prompt."
---

## Phase 1 — Triage

MUST:
- Get screenshot: `aws ec2 get-console-screenshot --instance-id <id>` — look for GRUB prompt or error
- Get system log: `aws ec2 get-console-output --instance-id <id>` — look for GRUB messages
- Identify the GRUB error type: missing kernel, wrong root, corrupt config

## Phase 2 — Remediate

MUST:
- Stop instance, snapshot root volume
- Attach root volume to rescue instance
- Mount and chroot into the filesystem
- Fix GRUB config: `grub2-mkconfig -o /boot/grub2/grub.cfg` (RHEL/AL2) or `update-grub` (Ubuntu)
- Reinstall GRUB if needed: `grub2-install /dev/xvdf` (adjust device)
- Detach, reattach as root, start

## Common Issues

- symptoms: "Screenshot shows 'grub rescue>' prompt"
  diagnosis: "GRUB cannot find its configuration or modules. Partition table or GRUB install corrupted."
  resolution: "Rescue instance: reinstall GRUB and regenerate config."

- symptoms: "GRUB shows 'error: file not found' for kernel"
  diagnosis: "Kernel file missing from /boot. May have been deleted or filesystem corrupted."
  resolution: "Rescue instance: chroot and reinstall kernel package."

## Output Format

```yaml
root_cause: "<corrupt_grub|missing_kernel|wrong_root_device|grub_install> — <detail>"
evidence:
  - type: screenshot
    content: "<GRUB error from screenshot>"
severity: CRITICAL
mitigation:
  immediate: "Rescue instance GRUB repair"
  long_term: "Keep backup kernel, test updates in staging"
```
