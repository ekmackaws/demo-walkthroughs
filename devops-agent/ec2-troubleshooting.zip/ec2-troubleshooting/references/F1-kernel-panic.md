---
title: "F1 — Kernel Panic"
description: "Diagnose and recover from kernel panic on EC2 instances"
status: active
severity: CRITICAL
triggers:
  - "Kernel panic"
  - "not syncing"
  - "VFS.*Unable to mount root"
  - "end Kernel panic"
owner: devops-agent
objective: "Identify the kernel panic cause and restore the instance to a bootable state"
context: "Kernel panics prevent the instance from booting. Common causes: corrupt kernel, missing initramfs, incompatible kernel modules, root filesystem not found, driver issues after instance type change. Visible in system log (get-console-output)."
---

## Phase 1 — Triage

MUST:
- Get system log: `aws ec2 get-console-output --instance-id <id>` — find the panic message
- Get screenshot: `aws ec2 get-console-screenshot --instance-id <id>` — visual state
- Classify the panic:
  - "VFS: Unable to mount root fs" → root device not found (wrong device name or missing driver)
  - "Kernel panic - not syncing: No init found" → corrupt root filesystem
  - "BUG: unable to handle kernel paging request" → kernel bug or memory corruption

SHOULD:
- Check if instance type was recently changed (Xen → Nitro requires NVMe drivers)
- Check if kernel was recently updated

## Phase 2 — Remediate

MUST:
- Stop the instance
- Detach root volume
- Attach to a rescue instance (same OS family)
- Mount the volume and investigate/fix:
  - Missing NVMe drivers: install nvme module in initramfs
  - Corrupt kernel: chroot and reinstall kernel package
  - Wrong root device: update GRUB config
- Detach from rescue, reattach as root to original instance, start

## Common Issues

- symptoms: "VFS: Unable to mount root fs on unknown-block(0,0)"
  diagnosis: "Root device not found. Common when migrating from Xen (xvda) to Nitro (nvme) instance types."
  resolution: "Rescue instance: install NVMe drivers, rebuild initramfs, update /etc/fstab to use UUID instead of device name."

- symptoms: "Kernel panic after yum/apt kernel update"
  diagnosis: "New kernel incompatible or corrupt initramfs."
  resolution: "Rescue instance: set previous kernel as default in GRUB, or rebuild initramfs for new kernel."

## Output Format

```yaml
root_cause: "<missing_driver|corrupt_kernel|wrong_root_device|initramfs> — <detail>"
evidence:
  - type: system_log
    content: "<kernel panic message from console output>"
severity: CRITICAL
mitigation:
  immediate: "Rescue instance repair"
  long_term: "Test kernel updates in staging, use UUID in fstab, keep previous kernel"
```
