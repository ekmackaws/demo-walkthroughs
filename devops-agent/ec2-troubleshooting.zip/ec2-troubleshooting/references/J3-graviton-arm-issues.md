---
title: "J3 — Graviton / ARM Architecture Issues"
description: "Diagnose issues specific to Graviton (ARM) instances"
status: active
severity: MEDIUM
triggers:
  - "arm64.*incompatible"
  - "Graviton.*error"
  - "architecture.*mismatch"
  - "exec format error"
owner: devops-agent
objective: "Resolve ARM architecture compatibility issues"
context: "Graviton instances (*.g suffix: m6g, c7g, t4g, etc.) use ARM64 architecture. Software must be compiled for arm64. x86_64 binaries will not run natively. Docker images must be multi-arch or arm64-specific."
---

## Phase 1 — Triage

MUST:
- Confirm instance architecture: `aws ec2 describe-instance-types --instance-types <type>` → ProcessorInfo.SupportedArchitectures
- Check AMI architecture matches: `aws ec2 describe-images --image-ids <ami-id>` → Architecture
- If application fails: check for x86_64 binaries on arm64 instance (`file <binary>`)

SHOULD:
- Check Docker images for multi-arch support
- Verify all dependencies have arm64 builds

## Common Issues

- symptoms: "'exec format error' when running application"
  diagnosis: "x86_64 binary on arm64 instance. Binary must be recompiled for arm64."
  resolution: "Use arm64 build of the application. For Docker, use multi-arch images."

- symptoms: "Docker container fails to start on Graviton"
  diagnosis: "Docker image is x86_64 only, no arm64 variant."
  resolution: "Build multi-arch Docker image or use arm64-specific image tag."

- symptoms: "Package installation fails on Graviton"
  diagnosis: "Package repository doesn't have arm64 builds for the required package."
  resolution: "Check for arm64/aarch64 package availability. May need to compile from source."

## Output Format

```yaml
root_cause: "<binary_architecture|docker_image|package_unavailable|ami_mismatch>"
evidence:
  - type: architecture_check
    content: "<file command output or Docker image manifest>"
severity: MEDIUM
mitigation:
  immediate: "Use arm64 compatible binaries/images"
  long_term: "Build CI/CD pipeline for multi-arch, test on Graviton in staging"
```
