---
title: "K1 — Scheduled Maintenance Events"
description: "Handle AWS scheduled maintenance events for EC2 instances"
status: active
severity: MEDIUM
triggers:
  - "scheduled.*maintenance"
  - "instance-reboot"
  - "system-reboot"
  - "instance-retirement"
owner: devops-agent
objective: "Proactively handle maintenance events to minimize downtime"
context: "AWS schedules maintenance for host updates, security patches, or hardware degradation. Events include: instance-reboot, system-reboot, system-maintenance, instance-retirement, instance-stop. You can often reschedule or preempt by stopping+starting."
---

## Phase 1 — Triage

MUST:
- Check scheduled events: `aws ec2 describe-instance-status --instance-ids <id>` → Events
- Identify event type and scheduled date
- Determine impact: reboot (brief downtime) vs retirement (must migrate)

SHOULD:
- Check all instances for upcoming events: `aws ec2 describe-instance-status --filters Name=event.code,Values=instance-reboot,system-reboot,instance-retirement`
- Plan maintenance window

## Phase 2 — Remediate

MUST:
- For instance-reboot/system-reboot: stop+start before the scheduled date to preempt (migrates to new host)
- For instance-retirement: stop+start (EBS-backed) or terminate+relaunch (instance-store-backed)
- For system-maintenance: stop+start to migrate off the host

SHOULD:
- Automate maintenance handling with EventBridge rules
- Use ASG for automatic replacement of retired instances

## Common Issues

- symptoms: "Scheduled instance-retirement event"
  diagnosis: "Underlying hardware degrading. Instance must be migrated."
  resolution: "Stop+start (EBS-backed) to migrate to new host. Do this before the scheduled date."

- symptoms: "Scheduled system-reboot"
  diagnosis: "Host needs a reboot for maintenance. Brief downtime expected."
  resolution: "Stop+start before the date to preempt, or let AWS reboot at the scheduled time."

## Output Format

```yaml
root_cause: "Scheduled maintenance — <event_type>"
evidence:
  - type: scheduled_event
    content: "<event details from describe-instance-status>"
severity: MEDIUM
mitigation:
  immediate: "Stop+start to preempt maintenance"
  long_term: "Automate with EventBridge, use ASG for auto-replacement"
```
