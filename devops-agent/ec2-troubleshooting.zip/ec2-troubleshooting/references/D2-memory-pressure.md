---
title: "D2 — Memory Pressure / OOM"
description: "Diagnose memory exhaustion and OOM kills on EC2 instances"
status: active
severity: HIGH
triggers:
  - "Out of memory"
  - "oom-killer"
  - "Cannot allocate memory"
  - "swap.*full"
owner: devops-agent
objective: "Identify the memory-consuming process and restore instance stability"
context: "EC2 does not have a native CloudWatch memory metric. Memory monitoring requires CloudWatch Agent or SSM. OOM kills are visible in system log (dmesg). Linux OOM killer selects processes based on oom_score."
---

## Phase 1 — Triage

MUST:
- CloudWatch Agent memory metric (if installed): `aws cloudwatch get-metric-statistics --namespace CWAgent --metric-name mem_used_percent`
- System log for OOM: `aws ec2 get-console-output --instance-id <id>` — search for "oom-killer" or "Out of memory"
- If SSM available: `free -m`, `cat /proc/meminfo`, `ps aux --sort=-%mem | head -20`

SHOULD:
- Check swap usage: `swapon --show` via SSM
- Check dmesg for OOM events: `dmesg | grep -i oom` via SSM
- Review memory trend if CloudWatch Agent is installed

MAY:
- Check /proc/<pid>/oom_score for critical processes
- Review /var/log/messages or journalctl for OOM history

## Phase 2 — Remediate

MUST:
- Identify the memory-consuming process and determine if it's a leak or legitimate usage
- If memory leak: restart the process as immediate fix, investigate root cause
- If legitimate usage: upgrade to instance type with more memory

SHOULD:
- Add swap space as a buffer (not a permanent fix)
- Configure OOM killer priorities to protect critical processes
- Install CloudWatch Agent for memory monitoring

## Common Issues

- symptoms: "Instance unresponsive, system log shows oom-killer"
  diagnosis: "Memory exhausted, kernel killed processes. Check which process was killed and why."
  resolution: "Upgrade instance type, fix memory leak, add swap as temporary buffer."

- symptoms: "No CloudWatch memory metric available"
  diagnosis: "CloudWatch Agent not installed. EC2 does not report memory natively."
  resolution: "Install and configure CloudWatch Agent for memory, disk, and process metrics."

## Output Format

```yaml
root_cause: "<memory_leak|undersized|no_swap|oom_kill> — <process_name>"
evidence:
  - type: system_log
    content: "<OOM killer output from dmesg>"
severity: HIGH
mitigation:
  immediate: "Restart process, add swap, or upgrade instance"
  long_term: "Fix memory leak, install CloudWatch Agent, configure OOM priorities"
```
