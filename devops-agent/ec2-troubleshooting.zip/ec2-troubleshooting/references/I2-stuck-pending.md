---
title: "I2 — Instance Stuck in Pending State"
description: "Diagnose instances stuck in 'pending' state during launch"
status: active
severity: HIGH
triggers:
  - "stuck.*pending"
  - "instance.*pending.*long"
  - "launch.*timeout"
owner: devops-agent
objective: "Identify the launch blocker and get the instance to running state"
context: "Instances normally transition from pending to running in under 2 minutes. Stuck pending can be caused by EBS volume issues (encrypted volume KMS access, snapshot restore), ENI attachment issues, or host allocation problems."
---

## Phase 1 — Triage

MUST:
- Confirm instance state: `aws ec2 describe-instances --instance-ids <id>` → State, StateReason
- Check StateReason for specific error message
- Check if root volume is encrypted (KMS access needed during launch)
- Check CloudTrail for RunInstances event details

SHOULD:
- Check if the root volume is being restored from a large snapshot (can take time)
- Check for EBS volume attachment issues
- Verify the subnet has available IP addresses

## Phase 2 — Remediate

MUST:
- If KMS issue: fix key permissions and relaunch
- If snapshot restore: wait for restore to complete (large snapshots take longer)
- If stuck > 10 minutes with no progress: terminate and relaunch

SHOULD:
- Use fast snapshot restore (FSR) for large snapshots to avoid slow first-launch
- Pre-warm AMIs by launching and creating a new AMI

## Common Issues

- symptoms: "Instance pending for > 5 minutes, encrypted root volume"
  diagnosis: "KMS key access issue during volume attachment."
  resolution: "Check KMS key permissions. Terminate and relaunch with correct permissions."

- symptoms: "Instance pending, large AMI (100+ GB)"
  diagnosis: "EBS snapshot restore in progress. First launch from a snapshot is slower."
  resolution: "Wait for restore. Use Fast Snapshot Restore for future launches."

## Output Format

```yaml
root_cause: "<kms_access|snapshot_restore|eni_attachment|host_allocation> — <detail>"
evidence:
  - type: instance_state
    content: "<StateReason from describe-instances>"
severity: HIGH
mitigation:
  immediate: "Fix blocker or terminate and relaunch"
  long_term: "Use FSR, pre-warm AMIs, validate KMS permissions in launch templates"
```
