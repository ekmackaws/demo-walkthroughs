---
title: "H2 — IMDS (Instance Metadata Service) Issues"
description: "Diagnose IMDS accessibility and credential delivery failures"
status: active
severity: HIGH
triggers:
  - "169.254.169.254.*timeout"
  - "Unable to locate credentials"
  - "EC2MetadataError"
  - "metadata.*unreachable"
owner: devops-agent
objective: "Restore IMDS access for credential delivery and metadata retrieval"
context: "IMDS provides instance metadata and temporary IAM credentials at 169.254.169.254. IMDSv2 uses session tokens (PUT then GET). Hop limit controls how many network hops can reach IMDS (1 = host only, 2 = containers). IMDS can be disabled entirely."
---

## Phase 1 — Triage

MUST:
- Check IMDS configuration: `aws ec2 describe-instances --instance-ids <id>` → MetadataOptions
  - HttpEndpoint: enabled/disabled
  - HttpTokens: required (IMDSv2 only) / optional (v1 and v2)
  - HttpPutResponseHopLimit: 1 or 2
- If HttpEndpoint=disabled: IMDS is completely off — that's the root cause
- If HttpPutResponseHopLimit=1 and running containers: containers can't reach IMDS

SHOULD:
- Check if iptables/firewall rules block 169.254.169.254
- Check if a proxy is intercepting metadata requests
- Verify the SDK/CLI version supports IMDSv2 (if HttpTokens=required)

MAY:
- Test IMDS from the instance via SSM: `curl -s http://169.254.169.254/latest/meta-data/`
- For IMDSv2: `TOKEN=$(curl -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600") && curl -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/`

## Common Issues

- symptoms: "Containers cannot get IAM credentials, host can"
  diagnosis: "HttpPutResponseHopLimit is 1. Containers need hop limit 2 (extra network hop)."
  resolution: "`aws ec2 modify-instance-metadata-options --instance-id <id> --http-put-response-hop-limit 2`"

- symptoms: "All IMDS requests fail (host and containers)"
  diagnosis: "IMDS disabled (HttpEndpoint=disabled) or network/firewall blocking 169.254.169.254."
  resolution: "Enable IMDS: `aws ec2 modify-instance-metadata-options --instance-id <id> --http-endpoint enabled`"

- symptoms: "IMDSv1 works but IMDSv2 fails"
  diagnosis: "SDK/CLI too old to support IMDSv2 token flow, or proxy stripping PUT headers."
  resolution: "Update SDK/CLI. If proxy issue, configure proxy to pass through IMDS headers."

## Output Format

```yaml
root_cause: "<disabled|hop_limit|imdsv2_incompatible|firewall_block|proxy> — <detail>"
evidence:
  - type: metadata_options
    content: "<MetadataOptions from describe-instances>"
severity: HIGH
mitigation:
  immediate: "Enable IMDS, increase hop limit, or update SDK"
  long_term: "Standardize IMDSv2 with hop limit 2 in launch templates"
```
