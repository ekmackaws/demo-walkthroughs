---
title: "G3 — NAT Gateway / NAT Instance Issues"
description: "Diagnose outbound internet connectivity failures through NAT"
status: active
severity: HIGH
triggers:
  - "NAT.*timeout"
  - "cannot reach.*internet.*private"
  - "NAT gateway.*error"
owner: devops-agent
objective: "Restore outbound internet connectivity for private subnet instances"
context: "NAT gateways provide outbound internet access for private subnet instances. NAT gateway must be in a public subnet with an EIP. Private subnet route table must have 0.0.0.0/0 → NAT gateway. NAT gateways are AZ-specific."
---

## Phase 1 — Triage

MUST:
- Check private subnet route table: 0.0.0.0/0 → nat-xxx
- Check NAT gateway state: `aws ec2 describe-nat-gateways --nat-gateway-ids <id>` — must be 'available'
- Check NAT gateway's subnet route table: must have 0.0.0.0/0 → igw-xxx
- Verify NAT gateway has an EIP associated

SHOULD:
- Check NAT gateway CloudWatch metrics: PacketsDropCount, ErrorPortAllocation
- Verify NAT gateway is in the same AZ as the private subnet (for optimal routing)
- Check if NAT gateway port allocation is exhausted (64K ports per destination)

MAY:
- Check if NAT instance (not gateway) is being used — verify source/dest check is disabled
- Check NAT gateway bandwidth (scales to 100 Gbps but may have burst limits)

## Common Issues

- symptoms: "Private instances cannot reach internet, NAT gateway exists"
  diagnosis: "Route table missing 0.0.0.0/0 → NAT gateway, or NAT gateway's subnet lacks IGW route."
  resolution: "Add route in private subnet RT. Verify NAT gateway subnet has IGW route."

- symptoms: "NAT gateway ErrorPortAllocation > 0"
  diagnosis: "Port exhaustion. Too many connections to the same destination from the same source."
  resolution: "Use multiple NAT gateways, or allocate multiple EIPs to the NAT gateway."

- symptoms: "NAT gateway state is 'failed'"
  diagnosis: "NAT gateway creation failed. Common causes: no EIP, subnet has no IGW route, or subnet has no available IPs."
  resolution: "Delete failed NAT gateway. Fix prerequisites and create a new one."

## Output Format

```yaml
root_cause: "<missing_route|nat_failed|port_exhaustion|no_igw_route> — <detail>"
evidence:
  - type: nat_gateway_state
    content: "<describe-nat-gateways output>"
severity: HIGH
mitigation:
  immediate: "Fix routing or replace NAT gateway"
  long_term: "Multi-AZ NAT gateways, monitor port allocation, use VPC endpoints for AWS services"
```
