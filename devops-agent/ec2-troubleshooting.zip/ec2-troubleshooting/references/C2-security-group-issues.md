---
title: "C2 — Security Group Misconfiguration"
description: "Diagnose connectivity issues caused by security group rules"
status: active
severity: MEDIUM
triggers:
  - "security group.*deny"
  - "traffic.*blocked"
  - "cannot connect.*port"
  - "VPC flow log.*REJECT"
owner: devops-agent
objective: "Identify the security group rule gap and restore connectivity"
context: "Security groups are stateful firewalls at the ENI level. They have ALLOW rules only (no deny). Default: deny all inbound, allow all outbound. Return traffic for allowed connections is automatically permitted."
---

## Phase 1 — Triage

MUST:
- List security groups on the instance: `aws ec2 describe-instances --instance-ids <id>` → SecurityGroups
- Review inbound rules: `aws ec2 describe-security-groups --group-ids <sg-ids>`
- Verify the required port/protocol is allowed from the source IP/CIDR/SG
- Check ALL security groups attached to the ENI (rules are aggregated as union)

SHOULD:
- Check VPC flow logs for REJECT entries matching the traffic pattern
- Verify source and destination security groups if using SG-to-SG references
- Check if the SG references another SG in a peered VPC (requires peering SG reference)

MAY:
- Use VPC Reachability Analyzer to validate the path

## Guardrails

- Security groups have NO deny rules. You cannot block specific IPs with SGs. Use NACLs for deny.
- Security groups are STATEFUL. If inbound is allowed, return traffic is auto-allowed. Don't add outbound rules for return traffic.
- SG rules referencing another SG only work within the same VPC (or peered VPC with SG reference enabled).
- Maximum 5 SGs per ENI (adjustable). Rules from all SGs are combined.

## Common Issues

- symptoms: "Inbound traffic blocked, SG appears to have correct rules"
  diagnosis: "Source IP may not match the rule. Check if source is behind NAT (public IP differs from private IP)."
  resolution: "Add rule for the actual source IP/CIDR. For internet traffic, use the public IP."

- symptoms: "Outbound traffic blocked"
  diagnosis: "Default SG allows all outbound. If custom SG removed the default outbound rule, specific outbound rules are needed."
  resolution: "Add outbound rule for the required destination and port."

- symptoms: "SG-to-SG reference not working across peered VPCs"
  diagnosis: "Cross-VPC SG references require VPC peering with 'allow remote SG references' enabled."
  resolution: "Enable SG reference in peering connection, or use CIDR-based rules instead."

## Output Format

```yaml
root_cause: "Security group — <missing_inbound|missing_outbound|wrong_source|cross_vpc_sg_ref>"
evidence:
  - type: security_group_rules
    content: "<current rules and the gap>"
severity: MEDIUM
mitigation:
  immediate: "Add the required security group rule"
  long_term: "Document required ports, use IaC for SG management"
```
