---
title: "E1 — EBS Attach/Detach Failures"
description: "Diagnose EBS volume attach or detach failures"
status: active
severity: HIGH
triggers:
  - "AttachVolume.*failed"
  - "volume.*attaching.*stuck"
  - "DetachVolume.*failed"
  - "volume.*busy"
  - "maximum.*volumes.*attached"
owner: devops-agent
objective: "Identify the attach/detach failure reason and restore volume access"
context: "EBS volumes must be in the same AZ as the instance. Attach limits depend on instance type (Nitro: 28 EBS + 2 NVMe, Xen: varies). Detach can fail if volume is in use by the OS. Force detach risks data corruption."
---

## Phase 1 — Triage

MUST:
- Check volume state: `aws ec2 describe-volumes --volume-ids <vol-id>` — state should be 'available' for attach
- Verify volume and instance are in the same AZ
- Check current attachment count vs instance limit: `aws ec2 describe-instance-types --instance-types <type>` → EbsInfo.MaximumAttachments
- For detach failures: check if volume is mounted in the OS

SHOULD:
- Check if volume is encrypted and instance role has KMS permissions
- For Nitro instances: check NVMe device mapping
- Check CloudTrail for AttachVolume/DetachVolume API errors

MAY:
- Check if volume is part of a RAID array or LVM group

## Common Issues

- symptoms: "AttachVolume fails with 'maximum number of volumes already attached'"
  diagnosis: "Instance has reached its EBS attachment limit."
  resolution: "Detach unused volumes. Check for ENIs consuming attachment slots (pre-Gen7 instances)."

- symptoms: "Volume stuck in 'attaching' state"
  diagnosis: "Underlying attachment issue. May be AZ mismatch or instance state issue."
  resolution: "Wait 10 minutes. If still stuck, force detach and retry. Check instance is running."

- symptoms: "DetachVolume fails, volume shows 'in-use'"
  diagnosis: "Volume is mounted in the OS. Must unmount before detaching."
  resolution: "Unmount the filesystem first (`umount`), then detach. Force detach as last resort (data corruption risk)."

## Output Format

```yaml
root_cause: "<az_mismatch|attachment_limit|volume_in_use|kms_permission|stuck_attaching>"
evidence:
  - type: volume_state
    content: "<describe-volumes output>"
severity: HIGH
mitigation:
  immediate: "Fix the specific blocker (unmount, free slots, fix AZ)"
  long_term: "Monitor attachment counts, use launch templates with correct AZ"
```
