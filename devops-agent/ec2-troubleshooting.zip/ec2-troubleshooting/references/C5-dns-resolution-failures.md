---
title: "C5 — DNS Resolution Failures"
description: "Diagnose DNS resolution failures for EC2 instances in VPC"
status: active
severity: MEDIUM
triggers:
  - "could not resolve host"
  - "DNS.*timeout"
  - "Name or service not known"
  - "NXDOMAIN"
owner: devops-agent
objective: "Identify the DNS resolution issue and restore name resolution"
context: "VPC DNS uses the Amazon-provided DNS server at VPC CIDR base +2 (e.g., 10.0.0.2). Requires enableDnsSupport=true on the VPC. Private hosted zones require enableDnsHostnames=true. Custom DHCP option sets can override the DNS server."
---

## Phase 1 — Triage

MUST:
- Check VPC DNS settings: `aws ec2 describe-vpc-attribute --vpc-id <vpc-id> --attribute enableDnsSupport`
- Check VPC DNS hostnames: `aws ec2 describe-vpc-attribute --vpc-id <vpc-id> --attribute enableDnsHostnames`
- Check DHCP options set: `aws ec2 describe-dhcp-options --dhcp-options-ids <id>` — look for domain-name-servers
- Verify security group allows outbound UDP/TCP port 53

SHOULD:
- Check if NACL blocks UDP/TCP port 53 outbound or return traffic
- If using Route 53 private hosted zones: verify the hosted zone is associated with the VPC
- Check /etc/resolv.conf inside the instance (via SSM) for correct nameserver

MAY:
- Test with `dig @169.254.169.253 <hostname>` (VPC DNS resolver) via SSM
- Check Route 53 Resolver rules if using hybrid DNS

## Common Issues

- symptoms: "All DNS resolution fails"
  diagnosis: "enableDnsSupport is false on the VPC, or DHCP options set points to unreachable DNS server."
  resolution: "Enable DNS support on VPC, or fix DHCP options set."

- symptoms: "Private hosted zone names don't resolve"
  diagnosis: "enableDnsHostnames is false, or hosted zone not associated with the VPC."
  resolution: "Enable DNS hostnames on VPC. Associate the private hosted zone with the VPC."

- symptoms: "DNS works for public names but not private"
  diagnosis: "Route 53 private hosted zone not associated with VPC, or resolver rule missing."
  resolution: "Associate hosted zone with VPC. Check Route 53 Resolver rules."

## Output Format

```yaml
root_cause: "<dns_support_disabled|dhcp_misconfigured|hosted_zone_not_associated|sg_blocking_dns>"
evidence:
  - type: vpc_attribute
    content: "<DNS settings from VPC>"
severity: MEDIUM
mitigation:
  immediate: "Enable DNS support/hostnames, fix DHCP options"
  long_term: "Use Route 53 Resolver for hybrid DNS, monitor DNS metrics"
```
