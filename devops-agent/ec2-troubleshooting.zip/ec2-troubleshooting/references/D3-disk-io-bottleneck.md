---
title: "D3 — Disk I/O Bottleneck"
description: "Diagnose disk I/O performance issues on EC2 instances"
status: active
severity: MEDIUM
triggers:
  - "VolumeQueueLength.*high"
  - "await.*high"
  - "iowait.*high"
  - "disk.*slow"
owner: devops-agent
objective: "Identify the I/O bottleneck and restore disk performance"
context: "Disk I/O bottlenecks can occur at the EBS volume level (IOPS/throughput limits), the instance level (EBS-optimized bandwidth), or the OS level (filesystem, I/O scheduler). gp2 volumes have burst credits that deplete under sustained load."
---

## Phase 1 — Triage

MUST:
- Check CloudWatch EBS metrics: VolumeReadOps, VolumeWriteOps, VolumeQueueLength, VolumeThroughputPercentage
- For gp2: check BurstBalance metric (0% = throttled to baseline 3 IOPS/GB)
- Check instance EBS bandwidth: `aws ec2 describe-instance-types --instance-types <type>` → EbsInfo
- If SSM available: `iostat -x 1 5`, `iotop -b -n 3`

SHOULD:
- Compare volume IOPS/throughput against provisioned limits
- Check if multiple volumes are competing for instance EBS bandwidth
- Identify the process generating the most I/O

MAY:
- Check filesystem fragmentation and mount options
- Review I/O scheduler configuration

## Common Issues

- symptoms: "gp2 BurstBalance at 0%, high latency"
  diagnosis: "gp2 burst credits exhausted. Volume throttled to baseline (3 IOPS/GB, min 100)."
  resolution: "Migrate to gp3 (3000 baseline IOPS regardless of size) or increase gp2 size for higher baseline."

- symptoms: "High IOPS but instance EBS bandwidth saturated"
  diagnosis: "Instance type EBS-optimized bandwidth is the bottleneck, not the volume."
  resolution: "Upgrade to instance type with higher EBS bandwidth."

- symptoms: "High iowait but low volume IOPS"
  diagnosis: "Filesystem or OS-level issue (fragmentation, sync writes, journaling)."
  resolution: "Check mount options (noatime, barrier=0 for non-critical), defragment, tune I/O scheduler."

## Output Format

```yaml
root_cause: "<gp2_burst_depleted|volume_iops_limit|instance_bandwidth|filesystem> — <detail>"
evidence:
  - type: cloudwatch_metric
    content: "<EBS metrics showing bottleneck>"
severity: MEDIUM
mitigation:
  immediate: "Migrate to gp3 or increase provisioned IOPS"
  long_term: "Right-size volumes and instance types for I/O requirements"
```
