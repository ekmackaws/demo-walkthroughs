---
title: "J2 — Bare Metal Instance Issues"
description: "Diagnose issues specific to bare metal EC2 instances"
status: active
severity: MEDIUM
triggers:
  - "bare metal.*boot"
  - "metal.*slow start"
  - "BIOS.*configuration"
owner: devops-agent
objective: "Resolve bare metal specific issues"
context: "Bare metal instances (.metal suffix) provide direct hardware access. They take longer to launch (5-20 minutes), have BIOS/UEFI access, and expose all hardware features. No hypervisor overhead but also no hypervisor-level protections."
---

## Phase 1 — Triage

MUST:
- Confirm instance type is bare metal: `aws ec2 describe-instances --instance-ids <id>` → InstanceType (*.metal)
- Check if slow launch is expected (bare metal takes 5-20 minutes to boot)
- Check system log for BIOS/UEFI messages

SHOULD:
- Verify AMI supports UEFI boot mode if required by the bare metal type
- Check if NVMe instance store volumes need initialization

## Common Issues

- symptoms: "Bare metal instance takes 15+ minutes to reach running state"
  diagnosis: "Normal behavior. Bare metal instances perform full hardware initialization."
  resolution: "This is expected. Plan for longer launch times in automation."

- symptoms: "Instance store NVMe volumes not visible"
  diagnosis: "Instance store volumes may need to be initialized/formatted on first use."
  resolution: "Use `lsblk` to find NVMe devices, then format and mount."

## Output Format

```yaml
root_cause: "<slow_boot_expected|bios_config|nvme_init|uefi_required>"
evidence:
  - type: system_log
    content: "<boot messages>"
severity: MEDIUM
mitigation:
  immediate: "Wait for boot or fix configuration"
  long_term: "Pre-warm AMIs for bare metal, automate NVMe initialization"
```
