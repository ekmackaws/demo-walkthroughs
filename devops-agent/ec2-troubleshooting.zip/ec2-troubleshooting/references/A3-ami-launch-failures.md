---
title: "A3 — AMI Launch Failures"
description: "Diagnose EC2 launch failures caused by AMI issues (permissions, region, architecture, encryption)"
status: active
severity: MEDIUM
triggers:
  - "InvalidAMIID"
  - "AMI.*not found"
  - "not authorized.*image"
  - "does not exist in.*region"
  - "architecture.*not supported"
owner: devops-agent
objective: "Identify the AMI issue and launch the instance with a valid AMI"
context: "AMIs are region-specific, architecture-specific, and permission-controlled. Common failures: AMI not shared to account, AMI in wrong region, ARM AMI on x86 instance type, encrypted AMI without KMS access."
---

## Phase 1 — Triage

MUST:
- Verify the AMI ID exists in the target region: `aws ec2 describe-images --image-ids <ami-id>`
- Check AMI architecture (x86_64 vs arm64) matches instance type architecture
- Check AMI permissions if using a shared/community AMI
- Check if AMI is encrypted and if the launch role has KMS decrypt permissions

SHOULD:
- Verify the AMI is not deprecated or deregistered
- Check if the AMI's root device type (ebs vs instance-store) is compatible with the instance type
- Verify ENA support flag matches instance type requirements (Nitro instances require ENA)

MAY:
- Check if the AMI was recently deregistered by the owner
- Verify boot mode (UEFI vs legacy BIOS) compatibility with instance type

## Common Issues

- symptoms: "InvalidAMIID.NotFound"
  diagnosis: "AMI does not exist in the target region. AMIs are region-specific."
  resolution: "Copy the AMI to the target region: `aws ec2 copy-image --source-region <src> --source-image-id <ami> --region <dst>`"

- symptoms: "Launch fails with architecture mismatch"
  diagnosis: "ARM AMI (arm64) on x86 instance type or vice versa."
  resolution: "Use matching instance type: arm64 AMI → Graviton instances (*.g suffix), x86_64 AMI → Intel/AMD instances."

- symptoms: "Launch fails with 'not authorized' on encrypted AMI"
  diagnosis: "Launch role lacks KMS permissions for the AMI's encryption key."
  resolution: "Grant kms:Decrypt and kms:CreateGrant on the CMK to the launch role."

## Output Format

```yaml
root_cause: "<ami_not_found|architecture_mismatch|permission_denied|encryption> — <detail>"
evidence:
  - type: api_error
    content: "<error from RunInstances or describe-images>"
severity: MEDIUM
mitigation:
  immediate: "Use correct AMI for region/architecture/permissions"
  long_term: "Automate AMI validation in launch templates"
```
