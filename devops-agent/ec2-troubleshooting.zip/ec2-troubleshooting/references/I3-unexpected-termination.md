---
title: "I3 — Unexpected Instance Termination"
description: "Diagnose why an instance was unexpectedly terminated"
status: active
severity: CRITICAL
triggers:
  - "instance.*terminated.*unexpectedly"
  - "Client.InstanceInitiatedShutdownBehavior"
  - "Server.SpotInstanceTermination"
  - "Client.InternalError"
owner: devops-agent
objective: "Identify the termination cause and prevent recurrence"
context: "Instances can be terminated by: user API call, ASG scale-in, Spot interruption, instance-initiated shutdown behavior set to 'terminate', scheduled retirement, or internal errors. StateReason in describe-instances provides the cause."
---

## Phase 1 — Triage

MUST:
- Check termination reason: `aws ec2 describe-instances --instance-ids <id>` → StateReason
- Common StateReason codes:
  - `Client.UserInitiatedShutdown` — user or automation called TerminateInstances
  - `Client.InstanceInitiatedShutdownBehavior` — OS shutdown triggered termination
  - `Server.SpotInstanceTermination` — Spot instance reclaimed
  - `Server.InternalError` — AWS infrastructure issue
  - `Client.InternalError` — often EBS/KMS issue
- Check CloudTrail for TerminateInstances API call (who/what terminated it)

SHOULD:
- Check if instance was part of an ASG (scale-in event)
- Check Spot instance interruption notices (2-minute warning)
- Check instance-initiated-shutdown-behavior attribute
- Check for scheduled retirement events

MAY:
- Check AWS Health Dashboard for infrastructure events
- Review ASG scaling policies and activities

## Common Issues

- symptoms: "StateReason: Client.InstanceInitiatedShutdownBehavior"
  diagnosis: "OS issued a shutdown/halt command and the instance's shutdown behavior is set to 'terminate'."
  resolution: "Change shutdown behavior to 'stop': `aws ec2 modify-instance-attribute --instance-id <id> --instance-initiated-shutdown-behavior stop`"

- symptoms: "StateReason: Server.SpotInstanceTermination"
  diagnosis: "Spot instance reclaimed by AWS due to capacity needs or price change."
  resolution: "Use Spot Fleet with diversified allocation, or use On-Demand for critical workloads."

- symptoms: "CloudTrail shows TerminateInstances from an ASG"
  diagnosis: "ASG scale-in terminated the instance."
  resolution: "Review ASG scaling policies. Use instance protection for critical instances."

## Output Format

```yaml
root_cause: "<user_terminated|shutdown_behavior|spot_interruption|asg_scalein|internal_error>"
evidence:
  - type: state_reason
    content: "<StateReason from describe-instances>"
  - type: cloudtrail
    content: "<TerminateInstances event details>"
severity: CRITICAL
mitigation:
  immediate: "Relaunch instance or let ASG replace"
  long_term: "Fix shutdown behavior, use instance protection, diversify Spot fleet"
```
