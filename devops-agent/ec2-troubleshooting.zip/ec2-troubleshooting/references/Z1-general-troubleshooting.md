---
title: "Z1 — General EC2 Troubleshooting (Catch-All)"
description: "Fallback SOP for EC2 issues that do not match any specific runbook"
status: active
severity: MEDIUM
triggers:
  - ".*"
owner: devops-agent
objective: "Systematically investigate an unknown EC2 issue, classify the failure domain, and match to an existing SOP or escalate"
context: "This SOP is invoked when symptoms don't match any of the specific runbooks. It provides a broad, methodical investigation that narrows the failure domain step by step."
---

## Phase 1 — Triage

MUST:
- Get instance details: `aws ec2 describe-instances --instance-ids <id>`
- Check instance state (running, stopped, terminated, pending, stopping)
- Check status checks: `aws ec2 describe-instance-status --instance-ids <id>`
- Get system log: `aws ec2 get-console-output --instance-id <id>`
- Get screenshot: `aws ec2 get-console-screenshot --instance-id <id>`
- Check for scheduled events in instance status

SHOULD:
- Check CloudWatch metrics: CPUUtilization, StatusCheckFailed, NetworkIn/Out
- Check CloudTrail for recent API calls affecting the instance
- If SSM available: run basic diagnostics (uptime, free -m, df -h, dmesg | tail)

## Phase 2 — Classify

Based on triage results, classify into a failure domain:
- Instance not running → Check state transitions (I1-I3)
- Status check failing → System (B1) or Instance (B2) status check
- Cannot connect → Connectivity (C1-C5)
- Performance degraded → Performance (D1-D5)
- Storage issues → Storage (E1-E4)
- Boot failure → Boot/Init (F1-F4)
- Network issues → Networking (G1-G4)
- Permission errors → IAM/Security (H1-H3)
- Instance type issues → Instance Types (J1-J3)
- Maintenance → Maintenance (K1-K3)

If classified: switch to the specific SOP immediately.
If unclassified: continue to Phase 3.

## Phase 3 — Deep Investigation

MUST:
- Check all CloudWatch metrics for anomalies
- Review system log thoroughly for any error patterns
- Check VPC configuration (SGs, NACLs, routes)
- Check EBS volume states
- Review recent CloudTrail events for changes

SHOULD:
- Use VPC Reachability Analyzer if connectivity is involved
- Check AWS Health Dashboard for service events
- Compare with a known-good instance of the same type

## Phase 4 — Report

MUST:
- State the investigation path taken
- State root cause if identified, or "unclassified" with best hypothesis
- List all evidence collected
- Recommend next steps

## Output Format

```yaml
root_cause: "<identified_cause OR unclassified>"
failure_domain: "<launch|status_check|connectivity|performance|storage|boot|networking|iam|instance_type|maintenance|unknown>"
investigation_path: "describe-instances → status checks → system log → <domain_classification>"
evidence:
  - type: instance_state
    content: "<instance details>"
  - type: system_log
    content: "<key findings>"
  - type: cloudwatch
    content: "<metric anomalies>"
severity: MEDIUM
mitigation:
  immediate: "<specific action if root cause found, or escalate>"
  long_term: "Implement monitoring for the identified failure pattern"
```
