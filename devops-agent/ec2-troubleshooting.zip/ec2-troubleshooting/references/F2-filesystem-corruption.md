---
title: "F2 — Filesystem Corruption / fsck"
description: "Diagnose and repair filesystem corruption preventing boot"
status: active
severity: HIGH
triggers:
  - "fsck.*error"
  - "UNEXPECTED INCONSISTENCY"
  - "filesystem.*corrupt"
  - "superblock.*invalid"
owner: devops-agent
objective: "Repair the corrupted filesystem and restore the instance to bootable state"
context: "Filesystem corruption can occur from unclean shutdown, EBS volume issues, or disk errors. The instance may hang at boot waiting for manual fsck input. Screenshot will show the fsck prompt."
---

## Phase 1 — Triage

MUST:
- Get screenshot: `aws ec2 get-console-screenshot --instance-id <id>` — look for fsck prompt
- Get system log: `aws ec2 get-console-output --instance-id <id>` — look for filesystem errors
- Identify which filesystem/partition is corrupted

## Phase 2 — Remediate

MUST:
- Stop the instance
- Snapshot the root volume (backup before repair)
- Detach root volume, attach to rescue instance
- Run fsck: `fsck -y /dev/xvdf1` (or appropriate device)
- Reattach as root volume, start instance

SHOULD:
- Check /etc/fstab for incorrect entries that could cause boot failure
- Remove fsck.mode=force from kernel parameters if set

## Common Issues

- symptoms: "Screenshot shows 'Press F to fix' or fsck prompt"
  diagnosis: "Filesystem corruption detected during boot. Instance waiting for manual input."
  resolution: "Rescue instance: run `fsck -y` on the affected partition."

- symptoms: "System log shows 'UNEXPECTED INCONSISTENCY; RUN fsck MANUALLY'"
  diagnosis: "Severe filesystem corruption requiring manual repair."
  resolution: "Rescue instance: snapshot first, then `fsck -y`. If fsck fails, restore from snapshot."

## Output Format

```yaml
root_cause: "<unclean_shutdown|disk_error|fstab_error> — filesystem corruption on <partition>"
evidence:
  - type: system_log
    content: "<fsck error messages>"
severity: HIGH
mitigation:
  immediate: "Rescue instance fsck repair"
  long_term: "Use journaling filesystem, configure auto-fsck, regular snapshots"
```
