---
title: "B3 — EBS Volume Status Check Failure"
description: "Diagnose EBS volume impairment and I/O issues"
status: active
severity: HIGH
triggers:
  - "volume status.*impaired"
  - "io-enabled.*insufficient-data"
  - "VolumeIOEnabled.*false"
owner: devops-agent
objective: "Identify the EBS volume issue and restore I/O or recover data"
context: "EBS volume status checks monitor I/O capability. Impaired volumes may have degraded performance or complete I/O failure. Causes include underlying storage infrastructure issues or volume corruption."
---

## Phase 1 — Triage

MUST:
- Check volume status: `aws ec2 describe-volume-status --volume-ids <vol-id>`
- Check volume details: `aws ec2 describe-volumes --volume-ids <vol-id>`
- Verify the volume is attached and the attachment state is 'attached'
- Check if the instance using this volume has status check failures

SHOULD:
- Check CloudWatch EBS metrics: VolumeReadOps, VolumeWriteOps, VolumeQueueLength, BurstBalance
- Check if auto-enable IO is configured on the volume

MAY:
- Check if other volumes on the same instance are affected
- Review AWS Health Dashboard for storage events

## Phase 2 — Remediate

MUST:
- If volume I/O is disabled: enable I/O to allow access (may have data inconsistency)
  `aws ec2 enable-volume-io --volume-id <vol-id>`
- If volume is impaired: create snapshot immediately for data recovery
- If root volume: stop instance, detach, create snapshot, create new volume from snapshot

SHOULD:
- Run filesystem check after enabling I/O (fsck for Linux, chkdsk for Windows)
- Monitor volume performance after recovery

MAY:
- Replace the volume with a new one created from the latest snapshot
- Consider migrating to io2 for higher durability (99.999%)

## Common Issues

- symptoms: "Volume status shows 'impaired', I/O disabled"
  diagnosis: "Underlying storage issue. Volume data may be inconsistent."
  resolution: "Enable I/O for access, snapshot immediately, run fsck, consider volume replacement."

- symptoms: "Volume queue length consistently high, latency increasing"
  diagnosis: "Volume IOPS or throughput limit reached. Not a status check failure but performance degradation."
  resolution: "See E3 (IOPS throttling runbook). Upgrade volume type or increase provisioned IOPS."

## Output Format

```yaml
root_cause: "<volume_impaired|io_disabled|storage_event> — <detail>"
evidence:
  - type: volume_status
    content: "<describe-volume-status output>"
severity: HIGH
mitigation:
  immediate: "Enable I/O, snapshot for recovery"
  long_term: "Use io2 for critical volumes, automate snapshots"
```
