---
title: "D5 — T-Series CPU Credit Depletion"
description: "Diagnose performance degradation on T-series instances due to CPU credit exhaustion"
status: active
severity: MEDIUM
triggers:
  - "CPUCreditBalance.*0"
  - "CPUSurplusCreditsCharged"
  - "T2.*slow"
  - "T3.*throttled"
owner: devops-agent
objective: "Restore CPU performance by managing credits or changing instance configuration"
context: "T-series instances (T2, T3, T3a, T4g) use CPU credits for bursting above baseline. T2 default: standard mode (hard throttle at 0 credits). T3/T3a/T4g default: unlimited mode (can go negative, charged per vCPU-hour). Baseline varies by instance size."
---

## Phase 1 — Triage

MUST:
- Check CPUCreditBalance: `aws cloudwatch get-metric-statistics --metric-name CPUCreditBalance`
- Check CPUCreditUsage: how fast credits are being consumed
- Check CPUSurplusCreditBalance (unlimited mode): negative credit balance
- Check CPUSurplusCreditsCharged: actual charges for surplus usage
- Determine if instance is in standard or unlimited mode

SHOULD:
- Check baseline CPU percentage for the instance size (e.g., t3.micro = 10%, t3.small = 20%)
- Review CPUUtilization pattern — sustained above baseline depletes credits

MAY:
- Calculate credit earn rate vs usage rate to predict depletion

## Phase 2 — Remediate

MUST:
- If T2 standard with 0 credits: enable unlimited mode or upgrade instance type
- If T3 unlimited with high surplus charges: workload exceeds burstable model, switch to fixed-performance (M/C series)
- If temporary spike: wait for credits to accumulate (earned at baseline rate)

SHOULD:
- Set CloudWatch alarm on CPUCreditBalance < threshold
- Evaluate if workload is truly burstable or sustained

## Common Issues

- symptoms: "T2 instance suddenly slow, CPUCreditBalance = 0"
  diagnosis: "T2 standard mode, credits exhausted. CPU throttled to baseline."
  resolution: "Enable T2 unlimited: `aws ec2 modify-instance-credit-specification --instance-credit-specifications InstanceId=<id>,CpuCredits=unlimited`"

- symptoms: "T3 unlimited with high CPUSurplusCreditsCharged"
  diagnosis: "Workload consistently exceeds baseline. Unlimited mode is expensive for sustained loads."
  resolution: "Switch to fixed-performance instance (m5/m6i) — often cheaper than T3 unlimited for sustained workloads."

## Output Format

```yaml
root_cause: "<credit_exhaustion|sustained_above_baseline|wrong_instance_class> — <detail>"
evidence:
  - type: cloudwatch_metric
    content: "<CPUCreditBalance and CPUUtilization data>"
severity: MEDIUM
mitigation:
  immediate: "Enable unlimited mode or upgrade instance"
  long_term: "Right-size to fixed-performance instance if workload is sustained"
```
