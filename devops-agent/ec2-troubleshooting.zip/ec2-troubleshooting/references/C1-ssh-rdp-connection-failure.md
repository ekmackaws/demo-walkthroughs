---
title: "C1 — SSH/RDP Connection Failure"
description: "Diagnose inability to connect to EC2 instances via SSH (Linux) or RDP (Windows)"
status: active
severity: HIGH
triggers:
  - "Connection timed out"
  - "Connection refused"
  - "Permission denied.*publickey"
  - "No route to host"
  - "port 22.*unreachable"
  - "port 3389.*unreachable"
owner: devops-agent
objective: "Identify the connectivity blocker and restore SSH/RDP access"
context: "SSH/RDP failures have a layered diagnosis path: instance state → status checks → security group → NACL → route table → OS-level firewall → SSH/RDP service → key/credentials. Work from outside in."
---

## Phase 1 — Triage (outside-in)

MUST:
- Verify instance is running: `aws ec2 describe-instances --instance-ids <id>` — state must be 'running'
- Check status checks: `aws ec2 describe-instance-status --instance-ids <id>` — both must pass
- Check security group allows inbound on port 22 (SSH) or 3389 (RDP) from your source IP
- Check NACL allows inbound on port 22/3389 AND outbound on ephemeral ports (1024-65535)
- Check route table has route to your source (IGW for public, VPN/DX for private)
- Verify instance has a public IP or you're connecting via private network

SHOULD:
- Use VPC Reachability Analyzer: `aws ec2 create-network-insights-path` to test connectivity
- Check system log for OS-level issues: `aws ec2 get-console-output --instance-id <id>`
- Verify the correct key pair was used (Linux SSH)
- Check if SSM Session Manager works as alternative access method

MAY:
- Check VPC flow logs for REJECT entries on port 22/3389
- Test with EC2 Instance Connect (Linux) as alternative

## Phase 2 — Remediate

Based on the layer where the block is found:

- Security group: Add inbound rule for SSH/RDP from your IP
- NACL: Add allow rule for inbound port 22/3389 and outbound ephemeral ports
- No public IP: Attach EIP or use SSM Session Manager / bastion host
- OS firewall (iptables/Windows Firewall): Fix via SSM or rescue instance
- SSH service down: Fix via SSM, serial console, or rescue instance
- Wrong key pair: Use EC2 Instance Connect or rescue instance to add correct key

## Common Issues

- symptoms: "Connection timed out (no response at all)"
  diagnosis: "Traffic not reaching the instance. Check: security group, NACL, route table, public IP, source IP."
  resolution: "Work through the network layers outside-in. Most common: SG missing inbound rule for your IP."

- symptoms: "Connection refused (immediate rejection)"
  diagnosis: "Traffic reaches the instance but SSH/RDP service is not listening. Instance is reachable but service is down."
  resolution: "Check system log for service errors. Use SSM to restart sshd/RDP service."

- symptoms: "Permission denied (publickey)"
  diagnosis: "SSH key mismatch. Wrong key pair, wrong username, or authorized_keys file corrupted."
  resolution: "Verify correct username (ec2-user, ubuntu, admin, centos). Use EC2 Instance Connect or rescue instance to fix authorized_keys."

## Output Format

```yaml
root_cause: "<sg_block|nacl_block|no_public_ip|route_missing|service_down|key_mismatch|os_firewall> — <detail>"
evidence:
  - type: network_check
    content: "<specific layer where block was found>"
severity: HIGH
mitigation:
  immediate: "Fix the blocking layer"
  long_term: "Use SSM Session Manager as backup access, configure VPC flow logs"
```
