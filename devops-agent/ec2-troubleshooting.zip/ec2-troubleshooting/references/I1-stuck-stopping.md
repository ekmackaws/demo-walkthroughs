---
title: "I1 — Instance Stuck in Stopping State"
description: "Diagnose instances stuck in 'stopping' state"
status: active
severity: HIGH
triggers:
  - "stuck.*stopping"
  - "instance.*stopping.*long"
  - "cannot stop"
owner: devops-agent
objective: "Resolve the stuck state and complete the stop operation"
context: "Instances can get stuck in 'stopping' when the underlying host has issues or the OS shutdown process hangs. AWS will eventually force-stop the instance, but this can take up to several hours."
---

## Phase 1 — Triage

MUST:
- Confirm instance state: `aws ec2 describe-instances --instance-ids <id>` → State
- Check how long the instance has been in 'stopping' state
- Check for scheduled maintenance events that may be related

SHOULD:
- Check system log for shutdown-related errors
- Check if the instance has instance store volumes (data will be lost)

## Phase 2 — Remediate

MUST:
- Wait — AWS will eventually force-stop the instance (can take up to several hours)
- If urgent: force stop is not available via API. Contact AWS Support for assistance.
- Do NOT try to terminate a stuck-stopping instance — it may also get stuck

SHOULD:
- Plan for data recovery if instance store volumes are involved
- Prepare a replacement instance

## Common Issues

- symptoms: "Instance in 'stopping' state for > 30 minutes"
  diagnosis: "OS shutdown process hung or underlying host issue."
  resolution: "Wait for AWS to force-stop. Contact AWS Support if urgent."

## Output Format

```yaml
root_cause: "Instance stuck stopping — OS shutdown hung or host issue"
evidence:
  - type: instance_state
    content: "<describe-instances showing stopping state and duration>"
severity: HIGH
mitigation:
  immediate: "Wait for force-stop or contact AWS Support"
  long_term: "Configure shutdown scripts to timeout, use ASG for replacement"
```
