---
title: "C3 — Network ACL Issues"
description: "Diagnose connectivity issues caused by NACL rules"
status: active
severity: MEDIUM
triggers:
  - "NACL.*deny"
  - "network ACL.*block"
  - "stateless.*firewall"
owner: devops-agent
objective: "Identify the NACL rule blocking traffic and restore connectivity"
context: "NACLs are stateless firewalls at the subnet level. They have numbered rules evaluated in order (lowest first). They support both ALLOW and DENY rules. Default NACL allows all traffic. Custom NACLs deny all by default."
---

## Phase 1 — Triage

MUST:
- Identify the subnet: `aws ec2 describe-instances --instance-ids <id>` → SubnetId
- Get NACL for the subnet: `aws ec2 describe-network-acls --filters Name=association.subnet-id,Values=<subnet-id>`
- Check BOTH inbound AND outbound rules (NACLs are stateless)
- Verify ephemeral port range (1024-65535) is allowed for return traffic

SHOULD:
- Check NACLs on BOTH source and destination subnets
- Verify rule ordering (lower number = higher priority, first match wins)

## Guardrails

- NACLs are STATELESS. You must allow BOTH directions explicitly.
- Rule 100 ALLOW + Rule 200 DENY = traffic ALLOWED (lower number wins).
- Default NACL allows all. Custom NACLs deny all by default (rule * DENY).
- Ephemeral ports (1024-65535) must be allowed for return traffic.
- NACLs apply to ALL instances in the subnet, not per-instance.

## Common Issues

- symptoms: "Traffic blocked despite security group allowing it"
  diagnosis: "NACL is denying the traffic. NACLs are evaluated before security groups."
  resolution: "Add NACL allow rule with lower number than any deny rule matching the traffic."

- symptoms: "Outbound works but responses don't come back"
  diagnosis: "NACL outbound allows the request but inbound blocks the ephemeral port return traffic."
  resolution: "Add inbound NACL rule allowing TCP/UDP on ports 1024-65535 from the destination."

## Output Format

```yaml
root_cause: "NACL — <inbound_deny|outbound_deny|ephemeral_blocked|rule_ordering>"
evidence:
  - type: nacl_rules
    content: "<NACL rules showing the block>"
severity: MEDIUM
mitigation:
  immediate: "Add or reorder NACL rules"
  long_term: "Use security groups as primary firewall, NACLs only for subnet-level deny"
```
