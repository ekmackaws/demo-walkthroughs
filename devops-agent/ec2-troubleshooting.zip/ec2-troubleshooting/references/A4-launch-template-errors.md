---
title: "A4 — Launch Template / Configuration Errors"
description: "Diagnose EC2 launch failures caused by invalid launch template or configuration parameters"
status: active
severity: MEDIUM
triggers:
  - "InvalidParameterCombination"
  - "InvalidBlockDeviceMapping"
  - "InvalidSubnetID"
  - "InvalidGroup"
  - "Unsupported"
owner: devops-agent
objective: "Identify the configuration error and fix the launch template or parameters"
context: "Launch templates can contain stale references (deleted subnets, SGs, KMS keys), incompatible parameter combinations (instance type vs EBS type, placement group constraints), or missing required parameters."
---

## Phase 1 — Triage

MUST:
- Get the exact error from CloudTrail RunInstances event
- Review the launch template: `aws ec2 describe-launch-template-versions --launch-template-id <id>`
- Validate all referenced resources exist (subnet, SG, key pair, IAM profile, AMI)
- Check parameter compatibility (instance type supports requested features)

SHOULD:
- Verify subnet has available IP addresses
- Check placement group constraints if specified
- Verify EBS volume type is supported in the target AZ

MAY:
- Compare with a previously successful launch template version

## Common Issues

- symptoms: "InvalidParameterCombination for EBS volume"
  diagnosis: "io2 Block Express volumes require Nitro instances. gp2/gp3 max size is 16 TiB."
  resolution: "Match EBS volume type to instance capabilities."

- symptoms: "InvalidSubnetID.NotFound"
  diagnosis: "Subnet referenced in launch template was deleted."
  resolution: "Update launch template with valid subnet ID."

- symptoms: "InvalidGroup.NotFound"
  diagnosis: "Security group referenced in launch template was deleted or is in a different VPC."
  resolution: "Update launch template with valid security group in the same VPC as the subnet."

## Output Format

```yaml
root_cause: "<invalid_parameter|stale_reference|incompatible_config> — <detail>"
evidence:
  - type: launch_template
    content: "<problematic parameter from template>"
severity: MEDIUM
mitigation:
  immediate: "Fix the specific parameter in launch template"
  long_term: "Validate launch templates before deployment, use IaC with dependency tracking"
```
