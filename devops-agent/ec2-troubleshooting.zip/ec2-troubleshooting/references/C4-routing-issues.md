---
title: "C4 — VPC Routing Issues"
description: "Diagnose connectivity failures caused by missing or incorrect VPC route table entries"
status: active
severity: HIGH
triggers:
  - "no route to host"
  - "network unreachable"
  - "blackhole.*route"
  - "cannot reach.*internet"
owner: devops-agent
objective: "Identify the routing gap and restore network path"
context: "VPC route tables control traffic flow. Each subnet is associated with one route table. Routes determine where traffic is sent: IGW (internet), NAT gateway, VPN, peering, TGW, or local VPC. Missing or blackhole routes cause connectivity failures."
---

## Phase 1 — Triage

MUST:
- Get the subnet's route table: `aws ec2 describe-route-tables --filters Name=association.subnet-id,Values=<subnet-id>`
- Check for required routes based on the traffic destination:
  - Internet: 0.0.0.0/0 → IGW (public subnet) or NAT gateway (private subnet)
  - Peered VPC: peer CIDR → pcx-xxx
  - On-premises: on-prem CIDR → vgw-xxx or tgw-xxx
  - Other VPC via TGW: VPC CIDR → tgw-xxx
- Check for blackhole routes (target resource deleted but route remains)
- Verify the local route (VPC CIDR → local) exists

SHOULD:
- Check if NAT gateway is in a public subnet with IGW route
- Verify IGW is attached to the VPC
- Check Transit Gateway route tables if using TGW

MAY:
- Use VPC Reachability Analyzer for end-to-end path validation
- Check VPC flow logs for traffic patterns

## Common Issues

- symptoms: "Instance in private subnet cannot reach internet"
  diagnosis: "Missing 0.0.0.0/0 → NAT gateway route, or NAT gateway is in a private subnet."
  resolution: "Add route 0.0.0.0/0 → nat-xxx. Ensure NAT gateway's subnet has 0.0.0.0/0 → igw-xxx."

- symptoms: "Route shows 'blackhole' state"
  diagnosis: "Target resource (NAT gateway, VPN, peering connection) was deleted but route remains."
  resolution: "Delete the blackhole route and create a new route pointing to a valid target."

- symptoms: "Cannot reach peered VPC"
  diagnosis: "Missing route for peer VPC CIDR, or peering connection not accepted, or DNS resolution not enabled."
  resolution: "Add route for peer CIDR → pcx-xxx. Accept peering. Enable DNS resolution on peering connection."

## Output Format

```yaml
root_cause: "<missing_route|blackhole|nat_misconfigured|igw_detached|peering_route> — <detail>"
evidence:
  - type: route_table
    content: "<route table showing the gap>"
severity: HIGH
mitigation:
  immediate: "Add or fix the route"
  long_term: "Use IaC for route management, monitor for blackhole routes"
```
