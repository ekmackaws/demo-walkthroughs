---
title: "A2 — Service Limit / Quota Exceeded"
description: "Diagnose EC2 launch failures due to service quotas (vCPU limits, EIP limits, etc.)"
status: active
severity: HIGH
triggers:
  - "InstanceLimitExceeded"
  - "vCPU.*limit"
  - "You have requested more instances than your current instance limit"
  - "AddressLimitExceeded"
owner: devops-agent
objective: "Identify the exhausted quota and either optimize usage or request an increase"
context: "EC2 quotas are per-region and per-instance-family for On-Demand vCPUs. Spot has separate vCPU limits. Quotas are NOT per-AZ. Common limits: On-Demand vCPUs, Spot vCPUs, EIPs, security groups per VPC, ENIs per region."
---

## Phase 1 — Triage

MUST:
- Identify which quota is exceeded from the error message
- Check current quota usage: `aws service-quotas get-service-quota --service-code ec2 --quota-code <code>`
- Check current usage: `aws ec2 describe-instances --filters Name=instance-state-name,Values=running` and count vCPUs
- Distinguish between On-Demand vCPU limits (L-1216C47A) and Spot vCPU limits (L-34B43A08)

SHOULD:
- Check if stopped instances are consuming quotas (they don't consume vCPU quota but do consume other limits)
- Review running instances for unused or oversized resources that could be right-sized

MAY:
- Check quota history: `aws service-quotas list-requested-service-quota-change-history --service-code ec2`

## Phase 2 — Remediate

MUST:
- Request quota increase if legitimately needed: `aws service-quotas request-service-quota-increase --service-code ec2 --quota-code <code> --desired-value <value>`
- If urgent: contact AWS Support for expedited quota increase

SHOULD:
- Terminate unused instances to free up quota
- Right-size over-provisioned instances to reduce vCPU consumption
- Use Spot or Reserved Instances to optimize costs while managing capacity

MAY:
- Consolidate workloads onto fewer, larger instances
- Distribute across regions if single-region quota is insufficient

## Common Issues

- symptoms: "InstanceLimitExceeded when launching On-Demand instances"
  diagnosis: "On-Demand vCPU quota exhausted for this instance family in this region."
  resolution: "Request quota increase via Service Quotas console or API. Typical approval: 1-3 business days."

- symptoms: "Launch fails but running instance count seems low"
  diagnosis: "vCPU quota is per-family. A few large instances (e.g., 4x m5.16xlarge = 256 vCPUs) can exhaust the default 64 vCPU limit."
  resolution: "Check vCPU count, not instance count. Request increase for the specific instance family."

## Output Format

```yaml
root_cause: "Quota exceeded — <quota_name> at <current>/<limit>"
evidence:
  - type: service_quota
    content: "<quota details from service-quotas API>"
severity: HIGH
mitigation:
  immediate: "Request quota increase or terminate unused instances"
  long_term: "Implement quota monitoring alerts, right-size instances"
```
