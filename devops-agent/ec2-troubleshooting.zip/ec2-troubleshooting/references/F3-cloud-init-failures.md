---
title: "F3 — Cloud-Init / User-Data Failures"
description: "Diagnose cloud-init and user-data execution failures during instance initialization"
status: active
severity: MEDIUM
triggers:
  - "cloud-init.*error"
  - "user-data.*failed"
  - "cloud-init.*timeout"
  - "cc_scripts_user.*failed"
owner: devops-agent
objective: "Identify the cloud-init failure and fix the initialization script"
context: "Cloud-init runs during first boot (and optionally on every boot). User-data scripts execute as root. Failures can leave the instance in a partially configured state. Logs are in /var/log/cloud-init.log and /var/log/cloud-init-output.log."
---

## Phase 1 — Triage

MUST:
- Check system log for cloud-init errors: `aws ec2 get-console-output --instance-id <id>`
- If SSM available: check `/var/log/cloud-init.log` and `/var/log/cloud-init-output.log`
- Check user-data content: `aws ec2 describe-instance-attribute --instance-id <id> --attribute userData`
- Verify user-data format (must start with `#!/bin/bash`, `#cloud-config`, or be base64 encoded)

SHOULD:
- Check if user-data script has syntax errors
- Verify network connectivity during cloud-init (some scripts need internet access)
- Check cloud-init status: `cloud-init status --long` via SSM

MAY:
- Re-run cloud-init: `cloud-init clean && cloud-init init` via SSM (for testing)

## Common Issues

- symptoms: "User-data script doesn't execute"
  diagnosis: "Missing shebang line (#!/bin/bash), or user-data not base64 encoded when required."
  resolution: "Add shebang line. Ensure proper encoding. Check instance metadata for user-data availability."

- symptoms: "Cloud-init times out waiting for metadata"
  diagnosis: "IMDS unreachable. Check if IMDS is enabled and hop limit is sufficient."
  resolution: "Enable IMDS, set hop limit to 2 if using containers. Check network path to 169.254.169.254."

- symptoms: "User-data runs but fails partway through"
  diagnosis: "Script error, missing dependency, or network issue during execution."
  resolution: "Check /var/log/cloud-init-output.log for the specific error. Fix the script."

## Output Format

```yaml
root_cause: "<script_error|missing_shebang|imds_timeout|network_during_init|encoding> — <detail>"
evidence:
  - type: cloud_init_log
    content: "<error from cloud-init logs>"
severity: MEDIUM
mitigation:
  immediate: "Fix user-data script and relaunch or re-run cloud-init"
  long_term: "Test user-data scripts in staging, use cloud-init modules over raw scripts"
```
