---
title: "G1 — ENI (Elastic Network Interface) Issues"
description: "Diagnose ENI attachment, detachment, and configuration issues"
status: active
severity: MEDIUM
triggers:
  - "AttachNetworkInterface.*failed"
  - "ENI.*limit"
  - "network interface.*error"
owner: devops-agent
objective: "Resolve ENI issues and restore network connectivity"
context: "Each instance type has a maximum number of ENIs and IPs per ENI. ENIs are AZ-specific. Primary ENI cannot be detached. Secondary ENIs can be moved between instances in the same AZ/subnet."
---

## Phase 1 — Triage

MUST:
- Check ENI limits for instance type: `aws ec2 describe-instance-types --instance-types <type>` → NetworkInfo
- List attached ENIs: `aws ec2 describe-network-interfaces --filters Name=attachment.instance-id,Values=<id>`
- Check ENI state and attachment status

SHOULD:
- Verify ENI and instance are in the same subnet/AZ
- Check if source/destination check needs to be disabled (NAT, forwarding)

## Common Issues

- symptoms: "Cannot attach additional ENI"
  diagnosis: "Instance type ENI limit reached."
  resolution: "Detach unused ENIs or upgrade instance type."

- symptoms: "ENI stuck in 'attaching' or 'detaching'"
  diagnosis: "Underlying attachment issue. May require force detach."
  resolution: "Wait 5 minutes. If stuck, force detach: `aws ec2 detach-network-interface --attachment-id <id> --force`"

- symptoms: "Secondary ENI attached but no connectivity"
  diagnosis: "OS needs configuration for the secondary ENI (route table, IP config)."
  resolution: "Configure OS-level routing for the secondary ENI. On Amazon Linux, use ec2-net-utils."

## Output Format

```yaml
root_cause: "<eni_limit|az_mismatch|os_config|stuck_state> — <detail>"
evidence:
  - type: eni_state
    content: "<describe-network-interfaces output>"
severity: MEDIUM
mitigation:
  immediate: "Fix ENI attachment or OS configuration"
  long_term: "Automate ENI management, use launch templates"
```
