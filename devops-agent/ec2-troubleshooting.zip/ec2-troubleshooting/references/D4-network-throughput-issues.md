---
title: "D4 — Network Throughput / Latency Issues"
description: "Diagnose network performance degradation on EC2 instances"
status: active
severity: MEDIUM
triggers:
  - "NetworkPacketsIn.*drop"
  - "network.*slow"
  - "packet loss"
  - "latency.*high"
  - "ENA.*throttle"
owner: devops-agent
objective: "Identify the network performance bottleneck and restore throughput"
context: "EC2 network performance depends on instance type (bandwidth allocation), ENA driver, placement (same AZ vs cross-AZ vs cross-region), and VPC configuration. Enhanced networking (ENA) is required for high performance. Network bandwidth is shared across all ENIs."
---

## Phase 1 — Triage

MUST:
- Check instance type network performance: `aws ec2 describe-instance-types --instance-types <type>` → NetworkInfo
- Check CloudWatch network metrics: NetworkIn, NetworkOut, NetworkPacketsIn, NetworkPacketsOut
- Check ENA metrics (Nitro instances): `ethtool -S <interface>` via SSM — look for bw_in_allowance_exceeded, pps_allowance_exceeded, conntrack_allowance_exceeded
- Verify enhanced networking is enabled: `aws ec2 describe-instance-attribute --instance-id <id> --attribute enaSupport`

SHOULD:
- Check if traffic is cross-AZ (adds latency and cost) or same-AZ
- Check for ENA driver version: `modinfo ena` via SSM
- Check MTU settings: `ip link show` via SSM

MAY:
- Run iperf3 between instances to measure actual throughput
- Check placement group membership for low-latency requirements

## Common Issues

- symptoms: "ENA metrics show bw_in_allowance_exceeded > 0"
  diagnosis: "Instance network bandwidth limit reached. Traffic is being shaped/dropped."
  resolution: "Upgrade to instance type with higher network bandwidth. Use placement groups for cluster traffic."

- symptoms: "High latency between instances"
  diagnosis: "Cross-AZ traffic (adds ~1ms), cross-region traffic, or network congestion."
  resolution: "Place communicating instances in same AZ. Use placement groups for low latency."

- symptoms: "Packet loss on small instance types"
  diagnosis: "Small instances have lower network allocation and burst credits. Sustained traffic exceeds allocation."
  resolution: "Upgrade instance type. Network performance scales with instance size."

## Output Format

```yaml
root_cause: "<bandwidth_limit|pps_limit|cross_az|ena_driver|mtu> — <detail>"
evidence:
  - type: ena_metrics
    content: "<ENA counter values showing throttling>"
severity: MEDIUM
mitigation:
  immediate: "Upgrade instance type or optimize traffic patterns"
  long_term: "Use placement groups, same-AZ deployment, ENA driver updates"
```
