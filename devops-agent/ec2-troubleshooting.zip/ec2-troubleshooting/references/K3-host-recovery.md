---
title: "K3 — Dedicated Host Recovery"
description: "Handle host-level failures for instances on Dedicated Hosts"
status: active
severity: HIGH
triggers:
  - "host.*failure"
  - "dedicated host.*impaired"
  - "host recovery"
owner: devops-agent
objective: "Recover instances from a failed Dedicated Host"
context: "Dedicated Hosts provide physical server isolation. If the host fails, instances are stopped. Host recovery (if enabled) automatically migrates instances to a new host. Without host recovery, manual intervention is needed."
---

## Phase 1 — Triage

MUST:
- Check host state: `aws ec2 describe-hosts --host-ids <host-id>` → State
- Check if host recovery is enabled: `aws ec2 describe-hosts` → HostRecovery
- Check instance states on the affected host

## Phase 2 — Remediate

MUST:
- If host recovery enabled: instances auto-migrate (may take time)
- If host recovery disabled: allocate new host, stop instances, modify host affinity, start on new host
- Verify instances are running on the new host

## Common Issues

- symptoms: "Dedicated Host state 'under-assessment' or 'released-permanent-failure'"
  diagnosis: "Host hardware failure. Instances are stopped."
  resolution: "If host recovery enabled, wait for auto-migration. Otherwise, allocate new host and migrate manually."

## Output Format

```yaml
root_cause: "Dedicated Host failure"
evidence:
  - type: host_state
    content: "<describe-hosts output>"
severity: HIGH
mitigation:
  immediate: "Wait for auto-recovery or manually migrate to new host"
  long_term: "Enable host recovery, use host resource groups for automation"
```
