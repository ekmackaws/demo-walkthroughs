---
title: "K2 — Instance Retirement"
description: "Handle EC2 instance retirement due to hardware degradation"
status: active
severity: HIGH
triggers:
  - "instance-retirement"
  - "hardware.*degradation"
  - "retirement.*notification"
owner: devops-agent
objective: "Migrate the instance before retirement deadline"
context: "AWS retires instances when underlying hardware is irreparably degraded. EBS-backed instances can be stopped+started to migrate. Instance-store-backed instances must be terminated (data lost). Retirement notifications come via email and Personal Health Dashboard."
---

## Phase 1 — Triage

MUST:
- Confirm retirement event: `aws ec2 describe-instance-status --instance-ids <id>` → Events
- Check if instance is EBS-backed or instance-store-backed
- Note the retirement deadline date

## Phase 2 — Remediate

MUST:
- EBS-backed: stop+start to migrate to new host (preserves EBS data, changes public IP)
- Instance-store-backed: backup data, terminate, relaunch from AMI
- Do this BEFORE the retirement deadline

SHOULD:
- Set up EventBridge rule for retirement notifications
- Use ASG for automatic handling

## Output Format

```yaml
root_cause: "Instance retirement — hardware degradation"
evidence:
  - type: retirement_event
    content: "<event details and deadline>"
severity: HIGH
mitigation:
  immediate: "Stop+start (EBS) or backup+terminate+relaunch (instance-store)"
  long_term: "EventBridge automation, ASG for auto-replacement"
```
