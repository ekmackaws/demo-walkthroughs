---
title: "G4 — VPC Peering / Transit Gateway Connectivity"
description: "Diagnose cross-VPC connectivity failures via peering or Transit Gateway"
status: active
severity: HIGH
triggers:
  - "peering.*unreachable"
  - "transit gateway.*timeout"
  - "cross-VPC.*connectivity"
owner: devops-agent
objective: "Restore cross-VPC connectivity"
context: "VPC peering is point-to-point, non-transitive. Transit Gateway is a hub for connecting multiple VPCs and on-premises networks. Both require route table entries in each VPC. Peering does not support overlapping CIDRs."
---

## Phase 1 — Triage

MUST:
- For peering: check peering connection state (must be 'active'): `aws ec2 describe-vpc-peering-connections`
- Check route tables in BOTH VPCs for routes to the peer CIDR
- Verify security groups allow traffic from the peer VPC CIDR
- Check NACLs in both subnets

SHOULD:
- For TGW: check TGW route tables: `aws ec2 describe-transit-gateway-route-tables`
- Verify TGW attachments are in 'available' state
- Check for overlapping CIDRs (peering does not support this)

MAY:
- Use VPC Reachability Analyzer for end-to-end path validation
- Check DNS resolution across peering (requires DNS resolution option enabled)

## Common Issues

- symptoms: "Peering connection active but traffic doesn't flow"
  diagnosis: "Missing routes in one or both VPC route tables."
  resolution: "Add route for peer VPC CIDR → pcx-xxx in both VPC route tables."

- symptoms: "TGW attachment available but no connectivity"
  diagnosis: "TGW route table missing route, or TGW route table not associated with the attachment."
  resolution: "Add route in TGW route table. Associate route table with the attachment."

- symptoms: "Peering fails with overlapping CIDR error"
  diagnosis: "Both VPCs have overlapping IP ranges. Peering does not support this."
  resolution: "Use different CIDRs, or use PrivateLink for specific service connectivity."

## Output Format

```yaml
root_cause: "<missing_route|peering_not_active|tgw_route_table|overlapping_cidr|sg_blocking>"
evidence:
  - type: peering_state
    content: "<peering or TGW state and route tables>"
severity: HIGH
mitigation:
  immediate: "Add routes and fix security groups"
  long_term: "Use IaC for cross-VPC routing, implement monitoring"
```
