---
title: "J1 — Nitro vs Xen Instance Migration Issues"
description: "Diagnose issues when migrating between Xen and Nitro instance types"
status: active
severity: HIGH
triggers:
  - "NVMe.*not found"
  - "xvd.*missing"
  - "ENA.*not supported"
  - "instance type change.*boot failure"
owner: devops-agent
objective: "Successfully migrate between Xen and Nitro instance types"
context: "Nitro instances use NVMe for EBS and ENA for networking. Xen instances use Xen virtual block devices (xvd*) and legacy networking. Migrating requires NVMe and ENA drivers in the AMI. Device names change: /dev/xvda → /dev/nvme0n1."
---

## Phase 1 — Triage

MUST:
- Check if the AMI has NVMe drivers: look for nvme module in initramfs
- Check if ENA is enabled on the AMI: `aws ec2 describe-images --image-ids <ami-id>` → EnaSupport
- Check /etc/fstab for device name references (must use UUID, not /dev/xvd*)
- Check system log for NVMe or ENA errors after instance type change

## Phase 2 — Remediate

MUST:
- Before migration: install NVMe drivers and ENA driver on the source instance
- Update /etc/fstab to use UUID or LABEL instead of device names
- Enable ENA on the AMI: `aws ec2 modify-instance-attribute --instance-id <id> --ena-support`
- Test by launching a new Nitro instance from the AMI before migrating production

## Common Issues

- symptoms: "Kernel panic after changing to Nitro instance type"
  diagnosis: "AMI lacks NVMe drivers. Root device not found as /dev/nvme0n1."
  resolution: "Change back to Xen type, install NVMe drivers, rebuild initramfs, then migrate."

- symptoms: "Instance launches but no network on Nitro"
  diagnosis: "ENA not enabled on the AMI or ENA driver not installed."
  resolution: "Install ENA driver, enable ENA support on the instance/AMI."

- symptoms: "Boot fails with 'unable to mount root' after migration"
  diagnosis: "/etc/fstab references /dev/xvda1 which doesn't exist on Nitro (it's /dev/nvme0n1p1)."
  resolution: "Use rescue instance to update /etc/fstab to use UUID."

## Output Format

```yaml
root_cause: "<missing_nvme_driver|missing_ena|fstab_device_names|ena_not_enabled>"
evidence:
  - type: system_log
    content: "<boot error from console output>"
severity: HIGH
mitigation:
  immediate: "Revert to previous instance type, fix drivers/config, then migrate"
  long_term: "Always use UUID in fstab, include NVMe+ENA in base AMIs"
```
