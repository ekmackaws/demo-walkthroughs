---
title: "H1 — Instance Profile / IAM Role Issues"
description: "Diagnose IAM permission failures for EC2 instances"
status: active
severity: HIGH
triggers:
  - "AccessDenied"
  - "UnauthorizedAccess"
  - "no instance profile"
  - "AssumeRole.*failed"
owner: devops-agent
objective: "Identify the IAM permission gap and restore API access"
context: "EC2 instances use instance profiles to assume IAM roles. The instance profile wraps an IAM role. Credentials are delivered via IMDS. Common issues: no instance profile attached, role missing required permissions, SCP blocking, or permission boundary limiting."
---

## Phase 1 — Triage

MUST:
- Check if instance has an instance profile: `aws ec2 describe-instances --instance-ids <id>` → IamInstanceProfile
- If no profile: that's the root cause — no IAM credentials available
- Check the role's policies: `aws iam list-attached-role-policies --role-name <role>` and `aws iam list-role-policies --role-name <role>`
- Verify the specific API action is allowed by the role's policies

SHOULD:
- Check for explicit deny in SCPs (organization level)
- Check for permission boundaries on the role
- Check resource-based policies on the target resource (S3 bucket policy, KMS key policy)
- Use IAM Policy Simulator to test the specific action

MAY:
- Check CloudTrail for the exact AccessDenied event with error details
- Check if the role's trust policy allows ec2.amazonaws.com to assume it

## Common Issues

- symptoms: "AccessDenied but role appears to have correct permissions"
  diagnosis: "SCP, permission boundary, or resource-based policy is denying. Or condition keys don't match."
  resolution: "Check SCPs, permission boundaries, and resource policies. Use CloudTrail for the exact denial reason."

- symptoms: "No credentials available on instance"
  diagnosis: "No instance profile attached, or IMDS unreachable."
  resolution: "Attach instance profile: `aws ec2 associate-iam-instance-profile`. Check IMDS accessibility (see H2)."

- symptoms: "Credentials work for some APIs but not others"
  diagnosis: "Role has partial permissions. Missing specific actions or resource ARNs."
  resolution: "Add the missing IAM permissions to the role's policy."

## Output Format

```yaml
root_cause: "<no_profile|missing_permission|scp_deny|permission_boundary|resource_policy>"
evidence:
  - type: iam_policy
    content: "<policy analysis showing the gap>"
severity: HIGH
mitigation:
  immediate: "Attach profile or add missing permissions"
  long_term: "Use least-privilege policies, test with IAM Policy Simulator"
```
