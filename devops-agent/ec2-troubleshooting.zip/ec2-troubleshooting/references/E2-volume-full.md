---
title: "E2 — Volume Full / Disk Space Exhaustion"
description: "Diagnose and remediate disk space exhaustion on EBS volumes"
status: active
severity: HIGH
triggers:
  - "No space left on device"
  - "disk.*full"
  - "DiskSpaceUtilization.*100"
  - "inode.*exhaustion"
owner: devops-agent
objective: "Free disk space or expand the volume to restore operations"
context: "Disk full can be caused by log accumulation, temp files, large deployments, or inode exhaustion (many small files). EBS volumes can be expanded online without downtime (Nitro instances). After expansion, the filesystem must be grown to use the new space."
---

## Phase 1 — Triage

MUST:
- If SSM available: `df -h` (space), `df -i` (inodes), `du -sh /* | sort -rh | head -20` (largest directories)
- Check volume size: `aws ec2 describe-volumes --volume-ids <vol-id>`
- Check system log for "No space left on device" errors

SHOULD:
- Identify the largest space consumers: logs, temp files, old deployments, core dumps
- Check if inode exhaustion (many small files) vs block exhaustion (large files)

MAY:
- Check CloudWatch Agent disk metrics if installed

## Phase 2 — Remediate

MUST:
- Free space immediately: clean logs, temp files, old packages
  - `journalctl --vacuum-size=100M`
  - `find /tmp -type f -mtime +7 -delete`
  - `yum clean all` or `apt-get clean`
- If more space needed: expand EBS volume online
  - `aws ec2 modify-volume --volume-id <vol-id> --size <new-size>`
  - Wait for modification to complete: `aws ec2 describe-volumes-modifications --volume-ids <vol-id>`
  - Grow filesystem: `growpart /dev/xvda 1 && resize2fs /dev/xvda1` (ext4) or `xfs_growfs /` (xfs)

SHOULD:
- Set up log rotation to prevent recurrence
- Configure CloudWatch alarm on disk usage > 80%

## Common Issues

- symptoms: "df -h shows 100% but du shows less total"
  diagnosis: "Deleted files still held open by processes. Space not freed until process releases the file handle."
  resolution: "`lsof +L1` to find deleted-but-open files. Restart the process holding them."

- symptoms: "df -i shows 100% inodes used"
  diagnosis: "Inode exhaustion from many small files (common with mail queues, session files, cache)."
  resolution: "Find and clean small file accumulations. Inode count is set at filesystem creation."

## Output Format

```yaml
root_cause: "<log_accumulation|large_files|inode_exhaustion|deleted_open_files> — <detail>"
evidence:
  - type: disk_usage
    content: "<df -h and du output>"
severity: HIGH
mitigation:
  immediate: "Clean space or expand volume"
  long_term: "Log rotation, disk monitoring alerts, auto-scaling storage"
```
