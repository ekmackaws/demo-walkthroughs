---
title: "E4 — Instance Store Data Loss"
description: "Diagnose and prevent instance store (ephemeral) data loss"
status: active
severity: CRITICAL
triggers:
  - "instance store.*lost"
  - "ephemeral.*data.*gone"
  - "NVMe.*missing"
  - "local disk.*empty"
owner: devops-agent
objective: "Understand the data loss cause and implement prevention measures"
context: "Instance store volumes are physically attached to the host. Data persists ONLY during the instance's running lifetime. Data is LOST on: stop, terminate, host failure, or hibernation. Data survives: reboot. Instance store is NOT backed up by AWS."
---

## Phase 1 — Triage

MUST:
- Confirm the instance type has instance store: `aws ec2 describe-instance-types --instance-types <type>` → InstanceStorageInfo
- Determine what event caused data loss: stop+start, termination, host failure, or scheduled maintenance
- Check if the instance was stopped (instance store data lost) or rebooted (data preserved)

SHOULD:
- Check CloudTrail for StopInstances or TerminateInstances events
- Check Personal Health Dashboard for host retirement or maintenance events
- Verify if the application was designed for ephemeral storage

MAY:
- Check if instance store volumes need to be reformatted after stop+start

## Phase 2 — Remediate

MUST:
- Accept that instance store data cannot be recovered after stop/terminate/host failure
- For future prevention: use EBS for persistent data, instance store only for temp/cache/scratch
- If data was critical: restore from application-level backups or replicas

SHOULD:
- Implement application-level replication for data on instance store
- Use instance store only for: caches, buffers, scratch data, temp files
- Configure applications to rebuild instance store data on boot

MAY:
- Consider using EBS instead of instance store for data that must persist
- Use RAID across instance store volumes for performance (not durability)

## Common Issues

- symptoms: "Data missing after stop+start"
  diagnosis: "Instance store data is always lost on stop. This is expected behavior, not a bug."
  resolution: "Use EBS for persistent data. Rebuild cache/temp data on start."

- symptoms: "Data missing after system status check failure and auto-recovery"
  diagnosis: "Auto-recovery migrates to new host. Instance store data is lost."
  resolution: "Design applications to handle instance store data loss gracefully."

## Output Format

```yaml
root_cause: "<stop_start|termination|host_failure|maintenance> — instance store data is ephemeral"
evidence:
  - type: event
    content: "<CloudTrail or Health event showing the trigger>"
severity: CRITICAL
mitigation:
  immediate: "Restore from backups or replicas"
  long_term: "Use EBS for persistent data, instance store only for ephemeral data"
```
