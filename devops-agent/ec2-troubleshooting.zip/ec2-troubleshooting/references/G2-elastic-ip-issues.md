---
title: "G2 — Elastic IP Issues"
description: "Diagnose Elastic IP allocation, association, and connectivity issues"
status: active
severity: MEDIUM
triggers:
  - "AddressLimitExceeded"
  - "EIP.*not associated"
  - "public IP.*changed"
owner: devops-agent
objective: "Resolve EIP issues and restore stable public IP connectivity"
context: "EIPs provide static public IPv4 addresses. Free when associated with a running instance. Charged when unassociated or associated with a stopped instance. Default limit: 5 per region. EIPs in VPC can be moved between instances."
---

## Phase 1 — Triage

MUST:
- List EIPs: `aws ec2 describe-addresses`
- Check if EIP is associated: look for AssociationId and InstanceId
- Verify the instance is running (EIP on stopped instance still costs money)

SHOULD:
- Check for unassociated EIPs (wasting money)
- Verify EIP quota: `aws service-quotas get-service-quota --service-code ec2 --quota-code L-0263D0A3`

## Common Issues

- symptoms: "Public IP changed after stop+start"
  diagnosis: "Instance was using auto-assigned public IP, not an EIP. Auto-assigned IPs change on stop+start."
  resolution: "Allocate and associate an EIP for a static public IP."

- symptoms: "AddressLimitExceeded"
  diagnosis: "EIP quota (default 5 per region) reached."
  resolution: "Release unused EIPs or request quota increase."

- symptoms: "EIP associated but instance unreachable from internet"
  diagnosis: "Missing IGW route, security group blocking, or NACL blocking."
  resolution: "Check route table has 0.0.0.0/0 → IGW. Check SG and NACL rules."

## Output Format

```yaml
root_cause: "<quota_exceeded|not_associated|missing_igw_route|auto_assigned_changed>"
evidence:
  - type: eip_state
    content: "<describe-addresses output>"
severity: MEDIUM
mitigation:
  immediate: "Associate EIP or fix routing"
  long_term: "Use EIPs for instances needing static IPs, clean up unused EIPs"
```
